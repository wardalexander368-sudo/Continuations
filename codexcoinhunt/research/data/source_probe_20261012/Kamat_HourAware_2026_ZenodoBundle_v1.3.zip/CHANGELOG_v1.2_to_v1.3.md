# CHANGELOG v1.2 to v1.3

**Bundle version:** v1.3
**Release date:** 2026-09-28
**Supersedes:** v1.2 (published 2026-08-03, version DOI 10.5281/zenodo.21780072)
**Reason:** documentation and manuscript-file correction. Data files unchanged.

## What changed

1. **Patent application numbers removed.** Each U.S. provisional patent application number is replaced by "a pending U.S. provisional patent application". The one back-reference in the manuscript's competing-interests statement ("claiming the benefit of priority ... from" a number) now reads "from the earlier application". Filing dates and entity status are unchanged. Affected files:
   - `manuscript/Kamat_HourAware_2026_v4.md`, `manuscript/Kamat_HourAware_2026_v4.html` and `manuscript/Kamat_HourAware_2026_v4.pdf`: the "Research program" paragraph at the end of Section I and the Competing Interests statement. The PDF was printed again from the edited HTML with the same settings. Its other text and layout are unchanged: pages 1 and 3 to 14 are identical to v1.2, the Competing Interests paragraph gains one line (one line moves onto page 16), and the page count stays at 16.
   - `README.md` (Competing Interests), `PROVENANCE.md` (filter-category anonymisation policy), `CHANGELOG_v1.0_to_v1.1.md` (the `trades.csv` row) and `zenodo_description.txt`.
2. **Journal-submission details removed.** The name, manuscript number and status of an earlier journal submission of the manuscript are removed from `README.md`, `CHANGELOG_v1.0_to_v1.1.md`, `CHANGELOG_v1.1_to_v1.2.md` and `zenodo_description.txt`. The manuscript files never contained them.
3. **`README.md` updated.** The version labels now read v1.3, the v1.2 version DOI is recorded, the file listing now includes the HTML rendering and all changelogs, the citation version is updated, and the description of the removed price-change columns is reworded.
4. **Sole-author wording:** one sentence in `CHANGELOG_v1.0_to_v1.1.md` and two in `PROVENANCE.md` are reworded in the third person. No number or definition changes.
5. **`checksums.txt`** regenerated; this file added.

## What did not change

- **Data files** (`data/trades.csv`, `data/rejection_outcomes.csv`, `data/scanner_2026-04-09.csv`, `data/scanner_2026-04-10.csv`): byte-identical to v1.2.
- **Figures** (`figures/fig1_architecture_v2.svg` to `figures/fig4_filter_effectiveness_v2.svg`): byte-identical to v1.2.
- **`audit.py` and `LICENSE`:** byte-identical to v1.2.
- **Every headline number** in the manuscript and in `PROVENANCE.md`.
- **Earlier versions** v1.0 (10.5281/zenodo.20043302), v1.1 (10.5281/zenodo.21636182) and v1.2 (10.5281/zenodo.21780072) remain archived under their own version DOIs, as with any Zenodo version.

## Verification

Run `sha256sum -c --strict checksums.txt` in the extracted bundle; every entry should report OK. Run `python3 audit.py` to reproduce the headline numbers from the data files.
