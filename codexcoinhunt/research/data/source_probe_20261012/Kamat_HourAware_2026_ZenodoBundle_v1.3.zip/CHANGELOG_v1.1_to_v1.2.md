# CHANGELOG — v1.1 → v1.2

**Bundle version:** v1.2
**Release date:** 2026-08-03
**Supersedes:** v1.1 (published 2026-07-27, version DOI 10.5281/zenodo.21636182)
**Reason:** manuscript-file correction. Data files unchanged.

## What changed

**Only the manuscript files (`manuscript/Kamat_HourAware_2026_v4.md`, `manuscript/Kamat_HourAware_2026_v4.pdf`, and the corresponding `manuscript/Kamat_HourAware_2026_v4.html`) were updated.**

The v1.1 bundle (published 2026-07-27) contained manuscript files produced during an intermediate build of the v4 revision. The final v4 build was completed 2026-07-29 (two days after v1.1 was published), and the manuscript files in v1.1 therefore did not reflect the final published v4 content. This correction re-publishes the bundle with the final v4 manuscript in place; nothing else in the bundle changes.

## What did NOT change

- **Data files** (`data/trades.csv`, `data/rejection_outcomes.csv`, `data/scanner_2026-04-09.csv`, `data/scanner_2026-04-10.csv`) — byte-identical to v1.1 (and to v1.0 for the three unredacted files).
- **Figures** (`figures/fig{1,2,3,4}_*.svg`) — byte-identical to v1.1.
- **Reproduction script** (`audit.py`) — byte-identical to v1.1.
- **Documentation** (`LICENSE`, `PROVENANCE.md`) — byte-identical to v1.1.
- **All headline empirical numbers** in the manuscript reproduce byte-for-byte from the same CSV files as in v1.1; `audit.py` still exits zero.
- **v1.0 (10.5281/zenodo.20043302) and v1.1 (10.5281/zenodo.21636182)** remain permanently archived under their own version DOIs, as with any Zenodo version.

## Detailed file-level delta v1.1 → v1.2

| File | v1.1 status | v1.2 status | Notes |
|---|---|---|---|
| `manuscript/Kamat_HourAware_2026_v4.md` | 46.6 KB (intermediate v4 build, 2026-07-27) | 53.4 KB (final v4 build, 2026-07-29) | Content matches the manuscript uploaded to the companion paper record 10.5281/zenodo.21636390 (new version issued 2026-08-03) |
| `manuscript/Kamat_HourAware_2026_v4.pdf` | 586.7 KB (intermediate v4 build) | 394.6 KB (final v4 build) | Same content; smaller due to build-pipeline differences |
| `manuscript/Kamat_HourAware_2026_v4.html` | *(not present in v1.1)* | 58.3 KB (final v4 build) | New file: HTML rendering of the manuscript for browser preview |
| `CHANGELOG_v1.1_to_v1.2.md` | *(not present)* | this file | Documents the v1.1 → v1.2 correction |
| `checksums.txt` | v1.1 hashes | Regenerated 2026-08-03 to include the new manuscript files + CHANGELOG | See file for updated SHA-256 lines |
| All other files | byte-identical | byte-identical | See `checksums.txt` |

## Verification

Run `sha256sum -c checksums.txt` in the extracted bundle. All entries should PASS.

To reproduce every headline number in the manuscript from the data CSVs, run `python3 audit.py` in the extracted bundle. Exit code 0 = every headline number reproduces; non-zero = a headline number does not reproduce.
