#!/usr/bin/env python3
"""
audit.py -- assertion-based reproduction of every headline number in

    Kamat, A. U. (2026). Hour-Aware Adaptive Risk Management for
    Autonomous Memecoin Trading on Solana DEXs: Evidence, Theory,
    and Design Lessons from a 15-Day Deployment.

Usage (from the bundle root):

    pip install pandas numpy scipy
    python3 audit.py

Behaviour:
    * Reads data/trades.csv (7 columns) and data/rejection_outcomes.csv.
    * Recomputes every headline number stated in the manuscript.
    * Asserts each value equals the manuscript number to the tolerance
      shown in the paper (typically 1e-4 for percentages, 1e-2 for
      cumulative-return sums, exact for integer counts).
    * On any mismatch, prints the failing check together with expected
      and actual values, and exits with status 1.
    * On full pass, prints a single success line and exits status 0.

    Reviewers can therefore run `python3 audit.py; echo $?` blind and
    treat a zero exit code as verification that the deposited CSVs
    reproduce the manuscript's headline figures.

Statistical conventions (fixed to match manuscript values exactly):
    * Skewness and excess kurtosis are POPULATION moments (m3 / m2^1.5
      and m4/m2^2 - 3), not the bias-corrected sample-moment defaults
      that pandas returns. Computed by hand from raw arrays.
    * Mann-Whitney U is the min of (U1, U2); the reported p-value is
      the two-sided asymptotic p with continuity correction and
      tie-corrected variance, matching scipy.stats.mannwhitneyu with
      alternative='two-sided', use_continuity=True, method='asymptotic'.
    * The trades.csv `date` field is the trade EXIT timestamp; entry
      hour is derived as (date - heldMin), consistent with the
      Section VI.A entry-hour analysis.

Tested against scipy 1.7+ and pandas 2.0+. Under those versions the
script prints "ALL HEADLINE NUMBERS REPRODUCE" and exits 0.
"""

import sys
import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu


def check(name, actual, expected, tol=1e-4):
    if isinstance(expected, int) and isinstance(actual, (int, np.integer)):
        ok = int(actual) == expected
    else:
        ok = abs(float(actual) - float(expected)) <= tol
    if not ok:
        print(f"FAIL: {name}")
        print(f"  expected: {expected}")
        print(f"  actual:   {actual}")
        print(f"  |diff|:   {abs(float(actual) - float(expected)):.6g}   (tolerance {tol})")
        sys.exit(1)
    print(f"OK   {name}: {actual}")


def pop_skew(x):
    x = np.asarray(x, dtype=float)
    d = x - x.mean()
    m2 = (d ** 2).mean()
    m3 = (d ** 3).mean()
    return m3 / m2 ** 1.5


def pop_excess_kurtosis(x):
    x = np.asarray(x, dtype=float)
    d = x - x.mean()
    m2 = (d ** 2).mean()
    m4 = (d ** 4).mean()
    return m4 / (m2 ** 2) - 3.0


# --- 1. Load and parse trades.csv ----------------------------------------

tr = pd.read_csv("data/trades.csv", parse_dates=["date"])
tr["pnl_pct"]     = tr["pnl"].str.rstrip("%").astype(float)
tr["solIn_num"]   = tr["solIn"].str.rstrip(" SOL").astype(float)
tr["heldMin_num"] = tr["heldMin"].str.rstrip("min").astype(float)
tr["entry_ts"]    = tr["date"] - pd.to_timedelta(tr["heldMin_num"], unit="m")
tr["entry_hour"]  = tr["entry_ts"].dt.hour

# --- 2. Closed-trade cohort (Abstract, Section VI) -----------------------

check("trade count n",                len(tr),                                            190)
check("win rate percent",             (tr["pnl_pct"] > 0).sum() / len(tr) * 100,          40.5263)
check("mean pnl percent",             tr["pnl_pct"].mean(),                                0.6196)
check("median pnl percent",           tr["pnl_pct"].median(),                             -3.5850)
check("cumulative pnl percent",       tr["pnl_pct"].sum(),                               117.7300, tol=1e-2)
check("net SOL",                     (tr["pnl_pct"] / 100 * tr["solIn_num"]).sum(),        0.03873, tol=5e-5)
check("population skewness",          pop_skew(tr["pnl_pct"]),                            -1.2146, tol=1e-4)
check("population excess kurtosis",   pop_excess_kurtosis(tr["pnl_pct"]),                  6.6132, tol=5e-4)

# --- 3. Top-N removal fragility (Section VI.E) ---------------------------

sorted_desc = tr["pnl_pct"].sort_values(ascending=False)
total = tr["pnl_pct"].sum()
for n_remove, expected in [(1, 61.14), (3, -50.58), (5, -160.49), (10, -414.19)]:
    remaining = total - sorted_desc.iloc[:n_remove].sum()
    check(f"cumulative pnl after removing top-{n_remove}", remaining, expected, tol=1e-2)

# --- 4. Entry-hour blacklist analysis (Section VI.A, Prediction 1) --------

blacklist_hours = [2, 13, 23]
bl   = tr.loc[tr["entry_hour"].isin(blacklist_hours),  "pnl_pct"]
rest = tr.loc[~tr["entry_hour"].isin(blacklist_hours), "pnl_pct"]

check("blacklist cohort n (entry hour)",  len(bl),     17)
check("blacklist mean pnl percent",       bl.mean(),  -11.60,  tol=1e-2)
check("other-hours cohort n",             len(rest),  173)
check("other-hours mean pnl percent",     rest.mean(), 1.82,   tol=1e-2)

mw = mannwhitneyu(bl, rest, alternative="two-sided", use_continuity=True, method="asymptotic")
U1 = float(mw.statistic)
U2 = len(bl) * len(rest) - U1
U_min = min(U1, U2)
check("Mann-Whitney U (min)",                                        int(U_min), 1345)
check("Mann-Whitney p (two-sided, asymptotic, continuity-corrected)", mw.pvalue, 0.5634, tol=1e-3)

rank_biserial = 1 - 2 * U_min / (len(bl) * len(rest))
check("rank-biserial r",                                              rank_biserial, 0.085, tol=5e-3)

# --- 5. Rejection-tracking cohort (Section VI.B, Prediction 2) ------------

rj = pd.read_csv("data/rejection_outcomes.csv")
rj["sampleTs"] = pd.to_datetime(rj["sampleTs"])
check("post-rejection sample count", len(rj), 4874)

event_key = ["rejectTs", "mint", "rejectReason"]
events = rj.groupby(event_key, sort=False)
check("distinct event count", events.ngroups, 184)


def event_ref_price(g):
    return g.sort_values("ageMin").iloc[0]["priceUsd"]


def event_lost_half(g):
    ref = event_ref_price(g)
    return bool(ref > 0 and g["priceUsd"].min() <= 0.5 * ref)


def event_samples_below_half(g):
    ref = event_ref_price(g)
    if ref <= 0:
        return 0
    return int((g["priceUsd"] <= 0.5 * ref).sum())


ev_lost = events.apply(event_lost_half)
check("events with min-price <= 50% of reference (aggregate)", int(ev_lost.sum()),                 33)
check("aggregate event lost-half percent",                     ev_lost.sum() / len(ev_lost) * 100,  17.9, tol=5e-2)

sample_below_by_event = events.apply(event_samples_below_half)
below_total = int(sample_below_by_event.sum())
check("post-rejection samples below 50% of reference (aggregate)", below_total,                    1267)
check("aggregate sample-level below-half percent",                below_total / len(rj) * 100,      26.0, tol=5e-2)

# --- 6. Per-filter cross-tab (PROVENANCE.md, Figure 4 subtitle) -----------

expected_pf = {
    "filter_1": (96, 11, 2126, 474),
    "filter_2": (56, 13, 1640, 336),
    "filter_3": ( 5,  4,  448, 271),
    "filter_4": ( 7,  3,  356,  40),
    "filter_5": (17,  2,  192, 146),
    "filter_6": ( 3,  0,  112,   0),
}

for fname, (e_ex, l_ex, s_ex, b_ex) in expected_pf.items():
    sub = rj[rj["rejectReason"] == fname]
    ev_sub = sub.groupby(event_key, sort=False)
    ev_lost_sub = ev_sub.apply(event_lost_half)
    below_sub   = ev_sub.apply(event_samples_below_half)
    check(f"{fname} event count",              ev_sub.ngroups,          e_ex)
    check(f"{fname} events lost-half",         int(ev_lost_sub.sum()),  l_ex)
    check(f"{fname} sample count",             len(sub),                s_ex)
    check(f"{fname} samples below-half",       int(below_sub.sum()),    b_ex)

# --- 7. Observation-window adequacy and censoring (Section VI.B, v1.2) ---

def event_span_min(g):
    ts = g["sampleTs"]
    return (ts.max() - ts.min()).total_seconds() / 60.0

def event_n_samples(g):
    return len(g)

ev_span = events.apply(event_span_min)
ev_n    = events.apply(event_n_samples)

check("events reaching 24h span",           int((ev_span >= 1440).sum()), 0)
check("single-sample events",               int((ev_n == 1).sum()),       87)
check("events with span under 1h",          int((ev_span < 60).sum()),    111)

mask_u1   = ev_span < 60
mask_1_6  = (ev_span >= 60)  & (ev_span < 360)
mask_6_12 = (ev_span >= 360) & (ev_span < 720)
mask_o12  =  ev_span >= 720
check("duration band under 1h - count",  int(mask_u1.sum()),   111)
check("duration band 1 to 6h - count",   int(mask_1_6.sum()),  25)
check("duration band 6 to 12h - count",  int(mask_6_12.sum()), 14)
check("duration band over 12h - count",  int(mask_o12.sum()),  34)
check("duration band under 1h - lost-half",  int(ev_lost[mask_u1].sum()),   0)
check("duration band 1 to 6h - lost-half",   int(ev_lost[mask_1_6].sum()),  6)
check("duration band 6 to 12h - lost-half",  int(ev_lost[mask_6_12].sum()), 8)
check("duration band over 12h - lost-half",  int(ev_lost[mask_o12].sum()),  19)

mask_ge6h = ev_span >= 360
check("restricted subset (>=6h) - events",       int(mask_ge6h.sum()),                                          48)
check("restricted subset (>=6h) - lost-half",    int(ev_lost[mask_ge6h].sum()),                                 27)
check("restricted subset (>=6h) - rate percent", float(ev_lost[mask_ge6h].sum()) / int(mask_ge6h.sum()) * 100,  56.25, tol=1e-2)

# Per-filter median follow-up span (PROVENANCE.md column, v1.2)
per_filter_median_span = {
    "filter_1":    0.0,
    "filter_2":   92.5,
    "filter_3": 1105.1,
    "filter_4":  390.0,
    "filter_5":    0.0,
    "filter_6":   15.1,
}
for fname, expected_med in per_filter_median_span.items():
    sub = rj[rj["rejectReason"] == fname]
    ev_sub = sub.groupby(event_key, sort=False)
    span_sub = ev_sub.apply(event_span_min)
    check(f"{fname} median follow-up span (min)", float(span_sub.median()), expected_med, tol=1e-1)

# --- Success -------------------------------------------------------------

print()
print("=" * 60)
print("ALL HEADLINE NUMBERS REPRODUCE FROM THE DEPOSITED CSVs.")
print("=" * 60)
sys.exit(0)
