# CHANGELOG v1.0 to v1.1

**Concept DOI (resolves to latest version):** 10.5281/zenodo.20043301
**v1.0 version DOI (permanent, unredacted):** 10.5281/zenodo.20043302, released 2026-05-05
**v1.1 version DOI:** assigned by Zenodo on publication
**v1.1 target release date:** 2026-07-27

> **Version label reconciliation.** Throughout this bundle, "v1.0" refers to the record Zenodo's UI labels *Version v1* (published 2026-05-05, version DOI 10.5281/zenodo.20043302). "v1.1" refers to this release, which was set to Version 1.1 on upload. Citations to either version reconcile to the same record on Zenodo.

## Summary

v1.0 was a data-only deposit. v1.1 adds the manuscript (Markdown source + PDF), the four supporting figures, a reproduction script (`audit.py`), and a per-filter provenance table (`PROVENANCE.md`); it also removes one column of `trades.csv` and updates the README to reflect the assigned Zenodo DOI and the current manuscript revision status.

## Files added in v1.1

| File | Size | Purpose |
|---|---|---|
| `manuscript/Kamat_HourAware_2026_v4.md` | ~52 KB | v4 Markdown source with figure references |
| `manuscript/Kamat_HourAware_2026_v4.pdf` | ~400 KB | v4 PDF |
| `figures/fig1_architecture_v2.svg` | 2.5 KB | Pipeline architecture diagram |
| `figures/fig2_pnl_by_hour_v2.svg` | 8.0 KB | Mean PnL by UTC entry hour |
| `figures/fig3_equity_curve_v2.svg` | 4.8 KB | Cumulative PnL equity curve |
| `figures/fig4_filter_effectiveness_v2.svg` | 4.0 KB | Per-filter forward-loss shares |
| `audit.py` | ~10 KB | Assertion-based reproduction of every headline number from the deposited CSVs; exits 0 on full pass, 1 on first mismatch with expected/actual/diff/tolerance printed. Verified against pandas 3.0 / numpy 2.4 / scipy 1.17. Includes assertions for the §VI.B observation-window statistics (event-span duration bands, single-sample counts, restricted-subset primary result, and per-filter median follow-up spans). |
| `PROVENANCE.md` | ~6 KB | Per-filter event and sample counts, per-filter median follow-up spans, and duration-stratified event counts (six anonymised categories) |
| `CHANGELOG_v1.0_to_v1.1.md` | this file | Version history |
| `zenodo_description.txt` | ~3 KB | Metadata for the Zenodo web form |

## Files updated in v1.1

| File | Change |
|---|---|
| `data/trades.csv` | `exitReason` column **removed** from v1.1. v1.0 carried twelve verbatim exit-trigger labels, several of which embedded per-tier threshold values; all are gone in v1.1. All seven other columns (`date`, `symbol`, `entryPrice`, `exitPrice`, `pnl`, `solIn`, `heldMin`) are unchanged: all 190 rows and all seven remaining columns are cell-for-cell identical to v1.0. Every headline number in the manuscript still reproduces from the seven-column v1.1 by direct arithmetic; `audit.py` verifies this. Rationale: the verbatim tier labels embed per-tier threshold values that are the subject of a pending U.S. provisional patent application. The v1.0 record remains permanently archived under its own version DOI (10.5281/zenodo.20043302), as with any Zenodo version. |
| `README.md` | Concept DOI (10.5281/zenodo.20043301) substituted for the earlier "PENDING" placeholder; v1.0 version DOI (10.5281/zenodo.20043302) recorded separately; new sections describing the manuscript addition and the four figures; companion-paper section updated with arXiv 2606.08232 and the manuscript revision status; citation block updated to cite the concept DOI (resolves to latest version); `exitReason` row removed from the schema table, with a note recording the removal; `date` field description updated to note it is the exit timestamp with entry derived as `date - heldMin`; reproduction snippet updated to derive entry hour rather than using exit hour directly. |

## Files unchanged (byte-identical to v1.0)

| File | SHA-256 (unchanged) |
|---|---|
| `data/rejection_outcomes.csv` | matches v1.0 |
| `data/scanner_2026-04-09.csv` | matches v1.0 |
| `data/scanner_2026-04-10.csv` | matches v1.0 |
| `LICENSE` | unchanged |

Readers who cited the v1.0 version DOI (10.5281/zenodo.20043302) can continue to do so; v1.1 supersedes v1.0 for the added manuscript, figures, and reproduction infrastructure, and for the `exitReason` removal. Readers wanting a citation that resolves to the current latest version should cite the concept DOI (10.5281/zenodo.20043301).

## What is new in the v4 manuscript (vs the v2 that accompanied v1.0)

The v4 manuscript is a revision with four content additions:

1. **Theoretical framing (new §III).** Three predictions from classical microstructure and reject-inference theory (Kyle 1985 informed-flow; reject-inference / off-policy evaluation; Bailey-Lopez de Prado 2014 deflated-Sharpe) are stated explicitly and each empirical results subsection is labelled with the prediction it tests.
2. **Significance statement (new paragraph in §I; new §VIII.B).** The paper's contribution is reframed as measurement infrastructure and three transferable design lessons, not as a claim about the specific trading system's performance.
3. **Generalisable design lessons (new §VII).** Three operational recommendations for future autonomous-trading measurement studies on AMM venues: counterfactual logging as standard telemetry; fragility disclosure as a first-order manuscript deliverable; hour-of-day stratification as a required check on any pooled-trade analysis, with the choice of stratification timestamp (entry versus exit) declared explicitly and justified against the theoretical interpretation invoked. The last lesson is sharpened in v1.1 to reflect the timestamp-semantics finding: entry hour is the causally interpretable variable under the Kyle (1985) informed-flow reading, and exit-time labelling migrates winners forward in the hour-of-day histogram by construction (winners' median hold 3.60 min versus losers' 0.60 min; the fourteen bucket-changing trades average +11.36 percent versus -0.23 percent for the other 176).
4. **Expanded literature positioning (rewritten §II).** Reference count expanded from 9 to 23, organised into four thematic subsections spanning classical microstructure, DEX/AMM microstructure, reject inference and off-policy evaluation, and backtest fragility.

Every headline number in the v4 manuscript reproduces from the deposited data files. No new data was collected.

## Verification

After downloading v1.1:

```bash
sha256sum -c checksums.txt
```

All files should verify against `checksums.txt`.
